# Materials API

consult `/src/materials/minetest.lua` at this time