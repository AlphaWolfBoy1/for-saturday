# Textures API

consult `/src/texture/minetest.lua` at this time