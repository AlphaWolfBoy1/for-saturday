--
-- constants
--
airutils.vector_up = vector.new(0, 1, 0)

--set min y-pos above which airplanes are seen on radar
airutils.radarMinHeight = 30

